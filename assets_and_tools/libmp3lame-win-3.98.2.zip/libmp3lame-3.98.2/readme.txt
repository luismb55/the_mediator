This is a pre-built DLL of libmp3lame from the lame-3.98
distribution.

This version was built with Visual Studio 2005 and exports
all of the current functions listed in lame.h.

To build, replace the file "lame-3.98.2\Dll\BladeMP3EncDLL.def"
in the LAME source code with the one in this archive and build
with Visual Studio.
